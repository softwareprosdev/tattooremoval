import { LoadingState } from "@/components/ui/LoadingState";

export default function Loading() {
  return <LoadingState label="Preparing your experience…" />;
}
